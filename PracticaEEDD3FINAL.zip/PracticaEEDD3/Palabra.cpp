
using namespace std;

#include "Palabra.h"
#include <iostream>
#include <cstring>

Palabra::Palabra():termino(""),siguientes(){}
Palabra::Palabra(string ntermino):termino(ntermino),siguientes() {}
Palabra::Palabra(const Palabra& orig):termino(orig.termino),siguientes(orig.siguientes) {}

Palabra& Palabra::operator=(const Palabra& p){
    if(this!=&p){
        termino=p.termino;
        siguientes=p.siguientes;
    }
    return *this;
}

bool Palabra::operator<(const Palabra& p){
    return termino<p.termino;
}

bool Palabra::operator==(const Palabra& p){
    return termino==p.termino;
}

string Palabra::getTermino()const{
    return termino;
}

void Palabra::setTermino(string t){
    termino = t;
}
void Palabra::nuevoSucesor(string termino){
//    cout << "llega a nuevo sucesor "<< termino <<endl;
    ListaEnlazada<Sucesor>::Iterador it=siguientes.iterador();
    bool encontrado=false;
    while(!it.fin()&&!encontrado){//Busco si existe el sucesor
        if(it.dato().GetCadena()==termino){//si existe aumento ocurrencias
            it.dato().SetNumOcurrencias(it.dato().GetNumOcurrencias()+1);
            encontrado=true;
        }
        it.siguiente();
    }
    if(!encontrado){
        Sucesor s(termino,1);
        siguientes.insertaFinal(s);//Sino existe lo inserto en siguientes
    }
    
}

ListaEnlazada<string> Palabra::sucesores(){//Devuelven los sucesores de la palabra
    //cout << termino << endl;
    ListaEnlazada<Sucesor>::Iterador it=siguientes.iterador();
    ListaEnlazada<string> sucesores;
    while(!it.fin()){
        string sucesor=it.dato().GetCadena();
        sucesores.insertaFinal(sucesor);
        it.siguiente();
    }
    return sucesores;
}

Palabra::~Palabra() {
}

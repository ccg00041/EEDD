#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>
#include "ErrorCargaFichero.h"
using namespace std;

#include "Diccionario.h"

Diccionario::Diccionario():palabras(){
    
}

Diccionario::Diccionario(const Diccionario& orig):palabras(orig.palabras) {
}

Diccionario::~Diccionario() { 
}

bool Diccionario::insertar(const string& termino){
    int pos;
    //
    Palabra p(termino);
    if(palabras.busquedaBinaria(p)==-1){
        bool encontrado=false;
        for(int i=0;i<palabras.tam()&& !encontrado;++i){
            if(palabras[i].getTermino()>termino){//1º termino mayor que 2º entonces inserto
                pos=i;//empieza en 0
                encontrado=true;
            }
        }
        if(pos==palabras.tam()){
//            cout<< "ENTRA EN UINT_MAX"<<endl;
            palabras.insertar(p,UINT_MAX);
        } else {
//            cout<<"va a insertar "<< p.getTermino() << " en la pos " << pos << endl;
            palabras.insertar(p,pos);
        }
        return true;
//        cout<<"Insertado correctamente en la posicion " << pos <<" el dato "<< termino << endl;
    }else{
        return false;
//        cout << "Existe esta palabra" << endl;
    }
}


Palabra& Diccionario::busca(const string& termino){
    Palabra p(termino);
    Palabra pa,&nula=pa;//creo una palabra nula para devolverla
    int posicion=palabras.busquedaBinaria(p);
    if(posicion==-1){
        return nula;
    } else {
        return palabras[posicion];
    }
}

void Diccionario::cargarPalabras(string nomFich){
    //leer fichero
    ifstream fe;
    string linea;
    unsigned int total=0;
    //cout<<"entra en carga palabras"<< endl;
    fe.open (nomFich.c_str());
    //cout<<"abre fichero"<< endl;
    if(fe.good()){
        while (!fe.eof()){
            getline (fe, linea);
            if (linea !=""){
                //crear palabra
                Palabra p(linea);
                //p.setTermino(linea); //Introduce bien cada linea en cada palabra
                palabras.insertar(p);//añadir palabra al vector
                //cout << "palabra " << p.getTermino() << endl;
                total++;
            }
        }
        //cout<<"Total de palabras de archivo: "<<total<<endl;
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }
       
    
}
void Diccionario::entrena(const string& frase){
    string palabra,sucesora;
    stringstream ss;
    ss<<frase;
    ss>>palabra;
    if(palabra!=""){
     while(!ss.eof()){
        ss>>sucesora;
        if(sucesora!=""){
            //Compruebo si existe en el diccionario
            Palabra p(palabra);
            int posicion=palabras.busquedaBinaria(p);
            if(posicion==-1){//sino existen las añado
                insertar(palabra);
                posicion=palabras.busquedaBinaria(p);
            }
            palabras[posicion].nuevoSucesor(sucesora);
            palabra=sucesora;
            sucesora="";
        } else break;
     }
    }
    
}



void Diccionario::usaCorpus(const string& nomfich){
    ifstream fe;
    string linea;
    unsigned int total=0;
    fe.open (nomfich.c_str());
    if(fe.good()){
        while (getline (fe, linea)){
            if (linea !=""){
                //cout << "entrena " << linea << " - total " << total << endl;
                entrena(linea);
                total++;
                if(total==20000){//LEE HASTA LA LINEA 20000
                    break;
                }
            }
        }
        //cout<<"Total de palabras de archivo: "<<total<<endl;
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }

}


#ifndef VDINAMICO_H
#define VDINAMICO_H

#include <stdexcept>
#include <climits>
#include <cmath>
#include <iostream>
#include "Palabra.h"
using namespace std;
template <class T>
class VDinamico {
public:
    VDinamico<T>();//iniciando tam fisico 1 y tamal 0
    VDinamico<T>(unsigned int tl);//pasando tam logico inicial, iniciando el fisico a la potencia de 2 inmediatamente superior a tamal
    VDinamico(const VDinamico<T>& orig);
    VDinamico<T>(const VDinamico<T>& origen,unsigned int inicio, unsigned int num);//constructor de copia parcial
    VDinamico<T> &operator=(VDinamico &v);
    T &operator[](unsigned int pos); //acceder a un dato L/E
    void insertar(const T& dato,unsigned int pos = UINT_MAX);//UINT_MAX constante -> sino se pasa, insertamos al final
    T borrar (unsigned pos = UINT_MAX);
    unsigned int tam(){ return tamal;};
    int busquedaBinaria(const T& dato);
    virtual ~VDinamico(){delete[] elementos;};
private:
    unsigned int tamal, tamaf;
    T* elementos;
    void aumenta();
    void disminuye();
};

template <class T>
VDinamico<T>::VDinamico():tamal(0),tamaf(1){
    elementos = new T[tamaf];
}

template <class T>
VDinamico<T>::VDinamico(unsigned int tl):tamal(tl),tamaf(pow(2,ceil(log2(tl)))){ 
    elementos=new T[tamaf];
    //cout << "creado vector con tamal " << tamal << " y tamaf " << tamaf << endl;
}

template <class T>
VDinamico<T>::VDinamico(const VDinamico<T>& orig):tamal(orig.tamal),tamaf(orig.tamaf){
    elementos = new T[tamaf];
    for(int i = 0; i < tamal; ++i){
        elementos[i] = orig.elementos[i];
    }
    
}

template <class T>
VDinamico<T>::VDinamico(const VDinamico<T>& origen, unsigned int inicio, unsigned int num):tamal(num),tamaf(pow(2,ceil(log2(num)))){
    if(inicio + num > origen.tam())throw std::out_of_range("VectorDinamico::constructor copia parcial, posicion no valida");
    elementos = new T[tamaf];
    for(int i = 0; i < tamal; ++i){
        elementos[i] = origen.elementos[inicio];
        ++inicio;
    }
}

template <class T>
VDinamico<T> &VDinamico<T>::operator=(VDinamico& v){
    if(this!=&v){
        delete[] elementos;
        tamal = v.tam();
        elementos = new T[v.tamaf];
        for(unsigned int i = 0; i < tamal; ++i){
            elementos[i] = v.elementos[i];
        }
    }
    return *this;
}

template <class T>
T &VDinamico<T>::operator [](unsigned int pos){
    if(pos >= tamal) throw std::out_of_range("VectorDinamico::operador[], posicion no valida");
    return this->elementos[pos];   
}
template <class T>
void VDinamico<T>::aumenta(){
    T *vaux;
    vaux = new T[tamaf = tamaf*2];
    for(unsigned int i = 0; i < tamal; ++i)
        vaux[i] = elementos[i];
    delete[] elementos;
    elementos = vaux;
}

template <class T>
void VDinamico<T>::disminuye(){
    tamaf = tamaf/2;
    T *vaux = new T[tamaf];
    for(unsigned int i = 0; i < tamal; ++i)
        vaux[i] = elementos[i];
    elementos = vaux;
}


template <class T>
void VDinamico<T>::insertar(const T& dato, unsigned int pos){
    if(pos==UINT_MAX){//inserta en posicion final
        if(tamal==tamaf)aumenta();
        elementos[tamal]=dato;
//        cout<<"Inserto al final "<< tamal<<endl;
    } else if(pos > tamal) throw std::out_of_range("VectorDinamico::insertar, posicion no valida");        
      else if(pos < tamal || pos==tamal){//inserta en posicion intermedia
          if(tamal==tamaf)aumenta();
          for(int x=0, i=tamal-1; i>=pos && x<tamal;x++,--i){
            elementos[i+1]=elementos[i];
          }
          elementos[pos]=dato;
//          cout <<"insertado en pos intermedia "<<pos << endl;
    }
    ++tamal;
}


template <class T>
T VDinamico<T>::borrar(unsigned pos){
    if(pos!=UINT_MAX && pos>=tamal){//al ser unsigned no compruebo pos<0
        throw std::out_of_range("VectorDinamico::borrar, posicion no valida");
    }
    T aux;
    if(tamal!=0){//si no esta vacío el vector
        if(tamal*3<tamaf)disminuye();
        if(pos!=UINT_MAX){//borra pos intermedia o principio
            if(pos<tamal){
                aux=elementos[pos];
                for(int i=pos;i<tamal-1;++i){
                    elementos[i]=elementos[i+1];
                }
            } else throw std::out_of_range("VectorDinamico::borrar, no hay elementos en esa posicion");
        } else {
            aux=elementos[tamal-1];
        }
    } else {
        throw std::out_of_range("VectorDinamico::borrar, vector sin elementos");
    }
    --tamal;
    return aux;
}

template <class T>
int VDinamico<T>::busquedaBinaria(const T& dato){
        int inf = 0;
    int sup = tamal - 1;
    int mitad;
    while( inf <= sup){
        mitad = (inf + sup)/2;
//        cout << "mitad " << mitad << endl;
//        cout << "comparando "<< v[mitad].getTermino() << endl; 
        if(elementos[mitad] == dato){                                    
//            cout << "son iguales " << mitad <<endl; 
            return mitad; 
        } 
        else if(elementos[mitad] < dato) inf = mitad + 1;
                 else sup = mitad - 1;
        
    }
    return -1;     
}
#endif /* VDINAMICO_H */


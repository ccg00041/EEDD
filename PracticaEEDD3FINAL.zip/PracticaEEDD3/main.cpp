

#include <cstdlib>
#include <iostream>
#include <list>
#include <vector>
#include <utility>
#include <string>
#include "Diccionario.h"
#include "ListaEnlazada.h"
#include "ErrorCargaFichero.h"
using namespace std;

/*
 * 
 */
void verSucesores(Palabra &p){
    ListaEnlazada<string> sucesores(p.sucesores());
    ListaEnlazada<string>::Iterador it=sucesores.iterador();
    cout << "Los sucesores de " <<p.getTermino() << " son:"<<endl;
    int numSucesores=0;
    while(!it.fin()){
        cout << it.dato() <<endl;
        it.siguiente();
        numSucesores++;
    }
    cout << "El numero de sucesores es "<<numSucesores<<endl;
}
VDinamico<string> mostrarSucesores(Palabra &pal){
    int i=0;
    VDinamico<string> posiciones;
    ListaEnlazada<std::string> lsuc(pal.sucesores());
    ListaEnlazada<std::string>::Iterador it(lsuc.iterador());
    cout << "Listado Sucesoras de " << pal.getTermino() << ": " << endl;
    while (!it.fin()){
        posiciones.insertar(it.dato());        
        it.siguiente();
    }
    //posiciones.ordenar();
    for (unsigned i=0; i<posiciones.tam(); i++){
        cout << i+1 << " -> " << posiciones[i] << endl;
    }
    return posiciones;   
}

int main(int argc, char** argv) {
    try {
        int numero;
        Diccionario d;
        d.cargarPalabras("listado-sin-acentos_v2.txt");

        int total=d.getTam();
        cout<<"--------MENU DEL PROGRAMA--------\n" <<endl;
        cout<<"1.- Entrenar diccionario \n"<<endl;
        cout<<"2.- UsaCorpus \n"<<endl;
        cin>>numero;
        
        switch(numero){
            case 1:{
                string frase="La pelota es naranja y roja y amarilla y grande y minuscula";
                d.entrena(frase);
                string palabra="y";
                Palabra p=d.busca(palabra);
                verSucesores(p);
                break;
            }
            case 2:{
                d.usaCorpus("corpus_spanish.txt");
                string palabra="y";
                Palabra p=d.busca(palabra);
                verSucesores(p);
                break;
            }
        }
    } catch (out_of_range &e) {
        cerr << "Fuera de rango " << e.what() << endl;
    } catch (ErrorCargaFichero &e) {
        cerr << "Error al cargar fichero" << e.what() << endl;
    }

    return 0;
}




#ifndef LISTAENLAZADA_H
#define LISTAENLAZADA_H
#include <iostream>

using namespace std;


template <class T>
class ListaEnlazada {
    class Nodo;
public:
    class Iterador {
        Nodo* nodo;
        friend ListaEnlazada;
    public:
        Iterador(Nodo* nNodo) : nodo(nNodo) {}
        bool fin() {return nodo == 0;}
        void siguiente() {nodo = nodo->sig;}
        T& dato() { return nodo->dato;}
        virtual ~Iterador(){}
    };

    ListaEnlazada() : cabecera(0), cola(0) {}
    ListaEnlazada(const ListaEnlazada& orig);
    ListaEnlazada& operator=(const ListaEnlazada &l);
    Iterador iterador() { return Iterador(cabecera);}
    T& inicio() {return cabecera->dato;}
    T& fin() {return cola->dato;}
    void insertaInicio(T& dato);
    void insertaFinal(T& dato);
    void inserta(Iterador& i, T& dato);
    void borrarInicio();
    void borrarFinal();
    void borra(Iterador& i);
//    void lee();
    ~ListaEnlazada();
private:

    class Nodo {
        friend ListaEnlazada;
        friend Iterador;
    public:
        T dato;
        Nodo* sig;
        Nodo(T& nDato, Nodo* nSig = 0) : dato(nDato), sig(nSig) {}
        virtual ~Nodo() {}
    };
    Nodo *cabecera, *cola;
};

template <class T>
ListaEnlazada<T>::ListaEnlazada(const ListaEnlazada& orig) {
    Nodo* pt = orig.cabecera;
    this->cabecera=0;
    this->cola=0;
    T* nuevo;
    if(orig.cabecera != 0){//Si la lista no esta vacia
        while(pt!=0){//mientras haya elementos
            nuevo = new T(pt->dato);
            this->insertaFinal(*nuevo);
            pt = pt->sig;
        }
    } 
}

template <class T>
ListaEnlazada<T>& ListaEnlazada<T>::operator=(const ListaEnlazada& l){
    if(this!=&l){
        if(this->cabecera!=0){
            //borrado previo
            Nodo* p=cabecera;
            Nodo* borrar;
            while(p->sig!=0){
                borrar=p;
                p=p->sig;
                delete borrar;
            }
            delete p;
        }
        //copia
        Nodo* pt = l.cabecera;
        this->cabecera=0;
        this->cola=0;
        T* nuevo;
        if(l.cabecera != 0){//Si la lista no esta vacia
            while(pt!=0){//mientras haya elementos
                nuevo = new T(pt->dato);
                this->insertaFinal(*nuevo);
                pt = pt->sig;
            }
        } 
    }
    return *this;
}

template <class T>
void ListaEnlazada<T>::insertaInicio(T& dato) {
    Nodo *nuevo;
    nuevo = new Nodo(dato, cabecera);
    //Si la lista estaba vacía
    if (cabecera == 0) {
        cola = nuevo;
    }
    cabecera = nuevo;
}

template <class T>
void ListaEnlazada<T>::insertaFinal(T& dato) {
    Nodo *nuevo;
    nuevo = new Nodo(dato, 0);
    if (cola != 0) {
        cola->sig = nuevo;
    }
    //Si la lista estaba vacía
    if (cabecera == 0) {
        cabecera = nuevo;
    }
    cola = nuevo;
}

template <class T>
void ListaEnlazada<T>::inserta(Iterador& i, T& dato) {
    if(!i.fin()){//si i apunta a un nodo
        if(i.nodo==cabecera){//inserta por el inicio
            this->insertaInicio(dato);
        } else if(i.nodo==cola){//Inserta por el final
            this->insertaFinal(dato);
        } else {//inserta en medio
            Nodo* anterior=0;
            if(cabecera!=cola){
                anterior=cabecera;
                while(anterior->sig!=i.nodo){
                    anterior=anterior->sig;
                }
            }
            Nodo* nuevo;
            nuevo = new Nodo(dato,i.nodo);
            
            anterior->sig=nuevo;
            
            if(cabecera==0){
                cabecera=cola=nuevo;
            }
        }
    }
}

template <class T>
void ListaEnlazada<T>::borrarInicio() {
    Nodo *borrado = cabecera;
    cabecera = cabecera->sig;
    delete borrado;
    //Si he borrado el último elemento de la lista
    if (cabecera == 0) {
        cola = 0;
    }
}

template <class T>
void ListaEnlazada<T>::borrarFinal() {
    Nodo *anterior = cabecera;
    if (cabecera != cola) {
        while (anterior->sig != cola) {
            anterior = anterior->sig;
        }
    }
    delete cola;
    cola = anterior;
    if (anterior != 0) {
        anterior->sig = 0;
    } else {
        cabecera = 0;
    }

}

template <class T>
void ListaEnlazada<T>::borra(Iterador& i) {
//    cout << "llega a borrar "<< i.fin()<<endl;
    if(!i.fin()){
        if(i.nodo==cabecera){
//            cout << "borra inicio"<<endl;
            this->borrarInicio();
        } else if(i.nodo==cola){
//            cout << "borra final"<<endl;
            this->borrarFinal();
        } else {
//            cout << "borra intermedio"<<endl;
            Nodo* anterior=0;
            
            if(cabecera!=cola){//si hay elementos
                anterior=cabecera;
                while(anterior->sig!=i.nodo){
                    anterior=anterior->sig;
                }
            }
            anterior->sig=i.nodo->sig;
            delete i.nodo;
        }
    }
}


template <class T>
ListaEnlazada<T>::~ListaEnlazada(){
    if(cabecera!=0){
        Nodo* ptr=cabecera;
        Nodo* borrar;
        while(ptr->sig!=0){
            borrar=ptr;
            ptr=ptr->sig;
            delete borrar;
            
        }
        delete ptr;
    }
}

#endif /* LISTAENLAZADA_H */


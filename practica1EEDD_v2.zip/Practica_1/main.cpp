/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: caro cubillo
 *
 * Created on 24 de septiembre de 2017, 8:53
 */

#include <cstdlib>
#include <iostream>
#include "Diccionario.h"
#include <cstring>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    Diccionario d;
    d.cargarPalabras("listado-general.txt");
    Palabra p("zapato");
    int pos;
    pos=d.buscar(p);
    
    cout <<  "posicion " << pos << endl;
    /*Diccionario d;
    Palabra p1("gato");
    Palabra p2("liebre");
    
    d.cargarPalabra("lista-palabra.txt");
    
    if (d.buscar(p1)>=0)
        cout<<p1.getTermno() + "esta en el diccionario";
    else
         cout<<p1.getTermno() + "No esta en el diccionario";
    
     if (d.buscar(p2)>=0)
        cout<<p2.getTermno() + "esta en el diccionario";
    else
         cout<<p2.getTermno() + "No esta en el diccionario";
    */
    return 0;
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VectorEstatico.cpp
 * Author: alumno
 * 
 * Created on 19 de septiembre de 2017, 11:05
 */

#include "VectorEstatico.h"
#include <stdexcept>

using namespace std;

VectorEstatico::VectorEstatico():TAM(80383){
    v = new Palabra[TAM];
}

VectorEstatico::VectorEstatico(const VectorEstatico& orig) {
    v = new Palabra[TAM];
    for(int i=0; i<TAM; ++i){
        v[i]=orig.v[i];
    }
}
//Palabra& VectorEstatico::operator[](int pos){
//    return v[pos];
//}
VectorEstatico::~VectorEstatico() {
    delete[] v;//Elimino el vector
}

void VectorEstatico::asignar(Palabra p, unsigned int pos){
 if (pos>= TAM)cout << "fuera de rango, asignar" << endl;//throw out_of_range("VectorEstatico::asigna, posicion no valida");
    v[pos].setTermino(p.getTermino());
    //cout << "ASIGNAR " << v[pos].getTermino() <<endl;
}

Palabra VectorEstatico::recupera(int pos){
    if (pos>=TAM || pos<0)cout << "fuera de rango, recupera" << endl;//throw out_of_range("VectorEstatico::asigna, posicion no valida");
    return v[pos]; 
}

long int VectorEstatico::busquedaDic(Palabra p){
    cout << "Entra busquedaDic" << endl;
//    int inf = 0;
//    int sup = TAM - 1;
//    int mitad;
//    while( inf <= sup){
//        mitad = (inf + sup)/2;
//        cout << "entra en el while compara 1 "  << endl;
//        cout << "mitad " << mitad << endl;
//        cout << v[mitad].getTermino() << endl; //EL VECTOR ESTA VACIO
//        if( v[mitad].getTermino() == p.getTermino())return mitad;
//        else if( v[mitad].getTermino().compare(p.getTermino()) > 0)sup=mitad-1;
//        else inf=mitad+1;
    int inf = 0;
    int sup = TAM - 1;
    int mitad;
    while( inf <= sup){
        mitad = (inf + sup)/2;
        cout << "entra en el while compara 1 "  << endl;
        cout << "mitad " << mitad << endl;
        cout << "comparando "<< v[mitad].getTermino() << endl; 
        if(v[mitad].getTermino() == p.getTermino()){//COMPARADOR == ESTA MAL
            cout << "son iguales " << mitad <<endl; 
            return mitad; 
        } 
             else if(v[mitad].getTermino().compare(p.getTermino()) < 0) inf = mitad + 1;
                 else sup = mitad - 1;
        
    }
    return -1;        
        
//    }
//    return -1;
}
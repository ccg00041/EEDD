/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.h
 * Author: alumno
 *
 * Created on 19 de septiembre de 2017, 11:05
 */

#ifndef DICCIONARIO_H
#define DICCIONARIO_H
#include "Palabra.h"
#include "VectorEstatico.h"


class Diccionario {
public:
    Diccionario();
    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    
    int buscar (const Palabra &p);
    //void insertar (const Palabra &p);
    Palabra leer(unsigned int pos);
    void cargarPalabras(string nomFich);
    
private:
    VectorEstatico palabras;

    
    
    
};

#endif /* DICCIONARIO_H */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabra.h
 * Author: alumno
 *
 * Created on 19 de septiembre de 2017, 11:04
 */

#ifndef PALABRA_H
#define PALABRA_H
#include <string>
using namespace std;


class Palabra {
public:
    Palabra();
    Palabra(string termino);
    Palabra(const Palabra& orig);
    string getTermino();
    void setTermino(string t);
//    bool operator<(string t);
    virtual ~Palabra();
private:
    string termino;

};

#endif /* PALABRA_H */


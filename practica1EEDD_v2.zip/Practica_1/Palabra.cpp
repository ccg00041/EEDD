/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Palabra.cpp
 * Author: alumno
 * 
 * Created on 19 de septiembre de 2017, 11:04
 */

using namespace std;

#include "Palabra.h"
#include <iostream>
#include <cstring>

Palabra::Palabra(){}
Palabra::Palabra(string termino) {
    this->termino = termino;
}

Palabra::Palabra(const Palabra& orig) {
    termino = orig.termino;
}

string Palabra::getTermino(){
    return termino;
}

void Palabra::setTermino(string t){
    termino = t;
    //cout << "setTermino" << endl;
}

//bool Palabra::operator<(string t){
//    cout <<"entra operator<" << endl;
//    char *terminoaux = strdup(termino.c_str());
//    char *taux = strdup(t.c_str());
//    if(strcmp(terminoaux,taux) == -1) return true;//-1 1º < 2º, 0 son iguales, 1 1º> 2º
//    return false;
//}

Palabra::~Palabra() {
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VectorEstatico.h
 * Author: alumno
 *
 * Created on 19 de septiembre de 2017, 11:05
 */

#ifndef VECTORESTATICO_H
#define VECTORESTATICO_H
#include "Palabra.h"
#include <string>
#include <cstring>
#include <stdexcept>
#include <iostream>

using namespace std;

class VectorEstatico {
public:
    VectorEstatico();
    VectorEstatico(const VectorEstatico& orig);
    //Palabra& operator[](int pos);
    virtual ~VectorEstatico();
    
    void asignar (Palabra p, unsigned int pos);//No se si dejar p con puntero
    Palabra recupera (int pos);
    long int busquedaDic(Palabra p);//le faltaba el long int
    bool comparar(string t);
    //int getTam(){return TAM;}
private:
    unsigned int TAM;
    Palabra* v;
    
};

#endif /* VECTORESTATICO_H */


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Diccionario.cpp
 * Author: alumno
 * 
 * Created on 19 de septiembre de 2017, 11:05
 */

using namespace std;
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>

#include "Diccionario.h"


Diccionario::Diccionario():palabras(){
    cout <<"Hace el constructor de diccionario" << endl;
}

Diccionario::Diccionario(const Diccionario& orig) {
    throw runtime_error ("[Diccionario] constructor ");
}

Diccionario::~Diccionario() { 
}

Palabra Diccionario::leer(unsigned int pos){
    return palabras.recupera(pos);
}

int Diccionario::buscar(const Palabra& p){
    long int pos;
    pos = palabras.busquedaDic(p);
    if(pos == -1){
        cout << "posición no valida"<< endl;//throw std::out_of_range("Diccionario::buscar, posicion no valida");
        return pos;
    }
    cout << "posición que llega a buscar " << pos << endl;
    return pos;
    
//    int pos=-1;
//    bool encontrado=false;
//    
//    
//    if(palabras.recupera(i)-> getTermino()== p.getTermino()){ 
//            
//    }
    

//    return pos;
}



void Diccionario::cargarPalabras(string nomFich){
    //leer fichero
    ifstream fe;
    string linea;
    unsigned int total=0;
    //cout<<"entra en carga palabras"<< endl;
    fe.open ("listado-general.txt");
    //cout<<"abre fichero"<< endl;
    if(fe.good()){
        while (!fe.eof()){
            getline (fe, linea);
            if (linea !=""){
                //crear palabra
                Palabra p;
                p.setTermino(linea); //Introduce bien cada linea en cada palabra
                //cout << "termino " << p.getTermino() << endl;
                //cout << p.getTermino() << endl;
                palabras.asignar(p,total);//añadir palabra al vector
                //cout << "vector palabras " << palabras[total].getTermino() <<endl;
                total++;
            }
        }
        cout<<"Total de palabras de archivo: "<<total<<endl;
        fe.close();
    }else{
        cerr<<"No se puede abrir el fichero"<<endl;
    }
    
    
    
    }
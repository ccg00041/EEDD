
using namespace std;

#include "Palabra.h"
#include <iostream>
#include <cstring>
#include <queue>

Palabra::Palabra():termino(""),siguientes(){}
Palabra::Palabra(string ntermino):termino(ntermino),siguientes() {}
Palabra::Palabra(const Palabra& orig):termino(orig.termino),siguientes(orig.siguientes) {}

Palabra& Palabra::operator=(const Palabra& p){
    if(this!=&p){
        termino=p.termino;
        siguientes=p.siguientes;
    }
    return *this;
}

bool Palabra::operator<(const Palabra& p){
    return termino<p.termino;
}

bool Palabra::operator==(const Palabra& p){
    return termino==p.termino;
}

string Palabra::getTermino()const{
    return termino;
}

void Palabra::setTermino(string t){
    termino = t;
}
void Palabra::nuevoSucesor(string termino){
    list<Sucesor>::iterator it(siguientes.begin());
    bool encontrado=false;
    while((it != siguientes.end()) && !encontrado){//Busco si existe el sucesor
        if(it->GetCadena() == termino){//si existe aumento ocurrencias
            it->SetNumOcurrencias(it->GetNumOcurrencias()+1);
            encontrado=true;
        }
        it++;
    }
    if(!encontrado){
        Sucesor s(termino,1);
        siguientes.push_back(s);
    }
    
}

list<string> Palabra::sucesores(){
    list<string> sucesores;
    priority_queue<Sucesor> colaPrioridad;
    list<Sucesor>::iterator it = siguientes.begin();
    
        while(it != siguientes.end()){
            colaPrioridad.push(*it);
            it++;
        }
        
        int contador=0;
        while(contador<10 && !colaPrioridad.empty() ){
            sucesores.push_back(colaPrioridad.top().GetCadena());
            /*QUITAR*/cout << " cout sucesores: prioridad de " << colaPrioridad.top().GetCadena() <<  " num ocurrencias " <<colaPrioridad.top().GetNumOcurrencias() <<endl;
            colaPrioridad.pop();
            contador++;
        }
    return sucesores;
}

Palabra::~Palabra() {
}

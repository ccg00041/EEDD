

#include "Sucesor.h"

Sucesor::Sucesor() {}
Sucesor::Sucesor(string ncadena, unsigned int nnumOcurrencias):cadena(ncadena),numOcurrencias(nnumOcurrencias) {
}

Sucesor::Sucesor(const Sucesor& orig):cadena(orig.cadena),numOcurrencias(orig.numOcurrencias) {
}

Sucesor::~Sucesor() {
}

Sucesor& Sucesor::operator=(const Sucesor& orig){
    if(this!=&orig){
        cadena=orig.cadena;
        numOcurrencias=orig.numOcurrencias;
    }
    return *this;
}

bool Sucesor::operator<(const Sucesor& s)const{
    return numOcurrencias<s.numOcurrencias;
}

void Sucesor::SetNumOcurrencias(unsigned int numOcurrencias) {
    this->numOcurrencias = numOcurrencias;
}

unsigned int Sucesor::GetNumOcurrencias() const {
    return numOcurrencias;
}

void Sucesor::SetCadena(string cadena) {
    this->cadena = cadena;
}

string Sucesor::GetCadena() const {
    return cadena;
}



#ifndef DICCIONARIO_H
#define DICCIONARIO_H

#include "Palabra.h"
#include <vector>


class Diccionario {
public:
    Diccionario();
    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    Palabra& busca(const string& termino);
    bool insertar (const string& termino);
    void cargarPalabras(string nomFich);
    int getTam(){return palabras.size();};
    void entrena(const string& frase);
    void usaCorpus(const string& nomfich);
    
private:
    vector<Palabra> palabras;
       
    
};

#endif /* DICCIONARIO_H */


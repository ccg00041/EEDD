
#include <cstdlib>
#include <iostream>
#include <list>
#include <vector>
#include <utility>
#include <string>
#include "Diccionario.h"
#include "ErrorCargaFichero.h"
using namespace std;

/*
 * 
 */
void verSucesores(Palabra &p){
    list<string> sucesores=p.sucesores();
    list<string>::iterator it=sucesores.begin();
    if(!sucesores.empty()){
        cout << "Los sucesores de " <<p.getTermino() << " son:"<<endl;
        int numSucesores=0;
        while(it != sucesores.end()){
            cout << *it <<endl;
            it++;
            numSucesores++;
        }
    } else {
        cout << p.getTermino() << " no tiene sucesores" << endl;
    }
}


int main(int argc, char** argv) {
//    try {
//
//       
//        Diccionario d;
//        d.cargarPalabras("listado-sin-acentos_v2.txt");
//
//        int total=d.getTam();
//        int numero;
//        cout<<"--------MENU DEL PROGRAMA--------" <<endl;
//        cout<<"1.- Entrenar diccionario "<<endl;
//        cout<<"2.- UsaCorpus "<<endl;
//        cout<<"3.- Salir"<< endl; 
//        cin>>numero;
//        
//        do{
//        switch(numero){
//            cout<<"--------MENU DEL PROGRAMA--------" <<endl;
//            cout<<"1.- Entrenar diccionario "<<endl;
//            cout<<"2.- UsaCorpus "<< endl;
//            cout<<"3.- Salir"<< endl; 
//            cin>>numero;
//            case 1:{
////                string linea="";
//                int num;
//                do{
//                    cout<<"--------SUBMENU DEL PROGRAMA--------" <<endl;
//                    cout<<"1.- Introducir frase "<<endl;
//                    cout<<"2.- Introducir palabra para ver sucesores "<< endl;
//                    cout<<"3.- Salir"<< endl; 
//                    cin >> num;
//                    
//                    
//                    switch(num){
//                        case 1:{
//                            char frase[500];
//                            cout << "Introduzca la frase " << endl;
//                            cin.getline(frase,500,'n');
//                            cout << "frase introducida" << frase << endl;
////                            cin.get(frase);
//                            d.entrena(frase);
//                            break;
//                        }
//                        case 2: {
//                            string palabra;
//                            cout << "Introduzca palabra para ver sucesores (para salir pulse exit)" << endl;
//                            cin >> palabra;
//                            Palabra p(d.busca(palabra));
//                            verSucesores(p);
//                            break;
//                        }
//                        case 3:
//                            num=3;
//                            break;
//                        default:{
//                            cout << "comando no valido, introduzca un numero " << endl;
//                            break;
//                        }
//                    }
//                }while(num != 3);
//                break;
//            }
//            case 2:{
//                d.usaCorpus("corpus_spanish.txt");
//                string palabra="las";
//                Palabra p=d.busca(palabra);
//                verSucesores(p);
//                cout << "la palabra " << d.busca("esta").getTermino() << endl;
//                break;
//            }
//            case 3:
//                numero=3;
//                break;
//            default:
//                cout << "comando no valido, introduzca un numero " << endl;
//                break;
//        }
//    }while(numero != 3);
//    
//    } catch (out_of_range &e) {
//        cerr << "Fuera de rango " << e.what() << endl;
//    } catch (ErrorCargaFichero &e) {
//        cerr << "Error al cargar fichero" << e.what() << endl;
//    }
    try {
        int numero;
        Diccionario d;
        d.cargarPalabras("listado-sin-acentos_v2.txt");
        int total=d.getTam();
        cout<<"--------MENU DEL PROGRAMA--------" <<endl;
        cout<<"1.- Entrenar diccionario "<<endl;
        cout<<"2.- UsaCorpus "<<endl;
        cin>>numero;
        
        switch(numero){
            case 1:{
                string frase="La pelota es naranja y roja y roja y roja y amarilla y amarilla y grande y minuscula y bonita y fea y gigante y pequeña y azul y verde y morada";
                d.entrena(frase);
                string palabra="y";
                Palabra p(d.busca(palabra));
                verSucesores(p);
                break;
            }
            case 2:{
                d.usaCorpus("corpus_spanish.txt");
                string palabra="y";
                Palabra p=d.busca(palabra);
                verSucesores(p);
                break;
            }
        }
    } catch (out_of_range &e) {
        cerr << "Fuera de rango " << e.what() << endl;
    } catch (ErrorCargaFichero &e) {
        cerr << "Error al cargar fichero" << e.what() << endl;
    }
            
    return 0;
}


#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include "ErrorCargaFichero.h"
using namespace std;

#include "Diccionario.h"

Diccionario::Diccionario():palabras(){
    
}

Diccionario::Diccionario(const Diccionario& orig):palabras(orig.palabras) {
}

Diccionario::~Diccionario() { 
}

bool Diccionario::insertar(const string& termino){
    vector<Palabra>::iterator it=palabras.begin();
    Palabra p(termino);
    it=lower_bound(palabras.begin(),palabras.end(),p);
    if(it == palabras.end() || it->getTermino() != termino){
        palabras.insert(it,p);
        return true;
    }else{
        return false;
    }
}




Palabra& Diccionario::busca(const string& termino){
    vector<Palabra>::iterator it=palabras.begin();
    Palabra p(termino);
    it=lower_bound(palabras.begin(),palabras.end(),p);
    if(it == palabras.end()){
        throw std::out_of_range("Diccionario::busca, no se encuentra esa palabra en el diccionario");
    }
    return *it;
}

void Diccionario::cargarPalabras(string nomFich){
    //leer fichero
    ifstream fe;
    string linea;
    unsigned int total=0;
    fe.open (nomFich.c_str());
    if(fe.good()){
        while (!fe.eof()){
            fe >> linea;
            if (linea !=""){
                //crear palabra
                Palabra p(linea);
                palabras.push_back(p);  //añadir palabra al final vector
                total++;
            }
        }
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }
       
    
}
void Diccionario::entrena(const string& frase){
    string termino,sucesora;
    stringstream ss;
    ss<<frase;
    ss>>termino;
    if(termino!=""){
     while(!ss.eof()){
        ss>>sucesora;
        if(sucesora!=""){
            //Compruebo si existe en el diccionario
            vector<Palabra>::iterator it=palabras.begin();
            Palabra p(termino);
            insertar(termino); //inserta sino existe y sino no inserta
            it=lower_bound(palabras.begin(),palabras.end(),p);//busco su posicion
            int pos=it-palabras.begin();
            palabras[pos].nuevoSucesor(sucesora);
            termino=sucesora;
            sucesora="";
        } else break;
     }
    }
}



void Diccionario::usaCorpus(const string& nomfich){
    ifstream fe;
    string linea;
    stringstream ss;
    unsigned int total=0;//QUITAR
    fe.open (nomfich.c_str());
    if(fe.good()){
        while (getline (fe, linea)){
            if (linea !=""){
                cout << "entrena " << linea << " - total " << total << endl;//QUITAR
                entrena(linea);
                total++;//QUITAR
                if(total==10){//QUITAR
                    break;
                }
            }
        }
        //cout<<"Total de palabras de archivo: "<<total<<endl; //QUITAR
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }

}

/*
 * 1 usuario interaciona texto redictivo
 * a su vez tiene un diccionario especifico suyo
 * 
 * sugerencia, detallado en pdf
 * 
 */

#ifndef USUARIO_H
#define USUARIO_H

#include <string>
#include <iostream>
#include <sstream>
#include "Diccionario.h"
#include "TextoPredictivo.h"
#include <list>
using namespace std;
/*
 * comprobar: operator=
 * hacer funciones: sugerencia y escribe frase
 */
class TextoPredictivo;

class Usuario {
public:
//    Usuario();
    Usuario();
//    Usuario(string nid="", string nnombre=""/*, TextoPredictivo *ntp*/);
    Usuario(string nid, string nnombre);
    Usuario(const Usuario& orig);
    Usuario& operator=(const Usuario &usuario); 
    list<string> sugerencia(const string &termino);
    void escribeFrase(string frase);
    //hacer un set textopredictivo textoPredictivo *x=0
    
    virtual ~Usuario();
    void setTp(TextoPredictivo* tp);
    TextoPredictivo* getTp() const;
private:
    string id;
    string nombre;
    TextoPredictivo *tp;//se implementa con * y no hay que destruirlo ya que es asociacion
    Diccionario miDicc;//al ser composicion hay que hacer delete
};

#endif /* USUARIO_H */


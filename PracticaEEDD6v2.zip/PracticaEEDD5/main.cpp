

#include <cstdlib>
#include <iostream>
#include "AVL.h"
#include "Diccionario.h"
#include "TextoPredictivo.h"
#include "ErrorCargaFichero.h"
#include <chrono>
using namespace std;

void verSucesores(list<string> sucesores, string palabra) {
    list<string>::iterator it = sucesores.begin();
    if (!sucesores.empty()) {
        cout << "Los sucesores de " << palabra << " son " << endl;
        while (it != sucesores.end()) {
            cout << *it << endl;
            it++;
        }
    } else {
        cout << palabra << " no tiene sucesores" << endl;
    }
}

/*
 * 
 */
int main(int argc, char** argv) {
//llamo al diccionario le cargo el corpus y luego se lo paso a texto predictivo
    Diccionario d;
    d.cargarPalabras("listado-sin-acentos_v2.txt");
    Palabra p(d.busca("heey"));
    cout << "palabra encontrada " << p.getTermino() << endl;
//    try {
//        auto start = std::chrono::system_clock::now();
//
//        int numero;
//        Diccionario d;
//        d.cargarPalabras("listado-sin-acentos_v2.txt");
//        TextoPredictivo texto(&d);
//        cout << "palabras cargadas " << d.getTam() << endl;
//
//        cout << "--------MENU DEL PROGRAMA--------" << endl;
//        cout << "1.- Entrenar diccionario " << endl;
//        cout << "2.- UsaCorpus " << endl;
//        cin>>numero;
//
//        switch (numero) {
//            case 1:
//            {
//                string frase = "La pelota es naranja y roja y roja y roja y amarilla y amarilla y grande y minuscula y bonita y fea y gigante y pequeÃ±a y azul y verde y morada";
//                texto.entrena(frase);
//                string palabra = "y";
//                verSucesores(texto.sugerencia(palabra), palabra);
//                break;
//            }
//            case 2:
//            {
//                d.usaCorpus("corpus_spanish.txt");
//                string palabra = "y";
//                verSucesores(texto.sugerencia(palabra), palabra);
//                break;
//            }
//        }
//        auto end = std::chrono::system_clock::now();
//        auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
//        cout << "Time spent (ms) : " << elapsed_ms << endl;
//    } catch (out_of_range &e) {
//        cerr << "Fuera de rango " << e.what() << endl;
//    } catch (ErrorCargaFichero &e) {
//        cerr << "Error al cargar fichero" << e.what() << endl;
//    }

    return 0;

}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Usuario.cpp
 * Author: Ana
 * 
 * Created on 14 de noviembre de 2017, 10:12
 */

#include "Usuario.h"

Usuario::Usuario() : id(""), nombre(""), miDicc() {
}

Usuario::Usuario(string nid, string nnombre) : id(nid), nombre(nnombre), miDicc() {
}
//Usuario::Usuario(string nid, string nnombre/*, TextoPredictivo *ntp*/) : id(nid), nombre(nnombre), miDicc() {
//}

Usuario::Usuario(const Usuario& orig) : id(orig.id), nombre(orig.nombre), miDicc(orig.miDicc), tp(orig.tp) {
}

Usuario& Usuario::operator=(const Usuario& usuario){
    if(this != &usuario){
        id = usuario.id;
        nombre = usuario.nombre;
        miDicc = usuario.miDicc; //necesita el operator =
        tp = usuario.tp;//necesita operator= o no hace falta poner al ser * y teniendo todos los usuarios acceso a este
    }
}
//Hacer setTextoPredictivo
list<string> Usuario::sugerencia(const string& termino) {//ocupa menos
    //Compruebo si esta en los dos diccionarios
    //sino esta en ninguno se inserta en tu diccionario
    //usa dos listas tp->sugerencia() 
    //captura excepcion sino existe si en el busca soltabamos excepcion
    //gestionar iterador, con las listas 
    Palabra p=miDicc.busca(termino);
}

void Usuario::escribeFrase(string frase) {
    //coge dos primeras palabras, llama al entrena de dicbase y devuelve el lógico, coge primera palabra y la segunda y busca y 
    //si una d
    //entrena de midicc y las añade, sino tiene alguna de ellas return false -> cojo la primera y la busco sino esta la inserto en midicc
    //y llamo al entrena pasandole esa y la segunda
    //entrena de midicc inserta palabra
    string termino, sucesor;
    stringstream ss;
    ss << frase;
    ss >> termino;
    if (termino != "") {
        while (!ss.eof()) {
            ss >> sucesor;
            if (sucesor != "") {
                //compruebo si existen en diccionario base
                bool enDiccBase = tp->entrena(termino,sucesor);
                if (!enDiccBase) { //si alguno de los dos o los dos no existen, los entrena miDicc
                    miDicc.entrena(termino, sucesor);
                }
                termino = sucesor;
                sucesor = "";
            } else break;
        }
    }
}

Usuario::~Usuario() {
    //delete de usuario?¿
}

void Usuario::setTp(TextoPredictivo* tp) {
    this->tp = tp;
}

TextoPredictivo* Usuario::getTp() const {
    return tp;
}



#ifndef TEXTOPREDICTIVO_H
#define TEXTOPREDICTIVO_H
#include "Diccionario.h"
#include "Usuario.h"

class Usuario;

class TextoPredictivo {
public:
    TextoPredictivo(Diccionario *ndiccIdioma);
    TextoPredictivo(const TextoPredictivo& orig);
    list<string> sugerencia(string termino);
    bool entrena(const string &termino, const string &sucesor);
    void nuevoUsuario(const string &id, const string &nombre);
    Usuario getUsuario(const string &id);
    //nuevousuario() comprobar que usuario no este,poner usu.setTp() en vez del this 
    //getusuario
    virtual ~TextoPredictivo();
private:
    Diccionario *dicBase;//hacer delete?es composicion
    map<string,Usuario> usuarios;//composicion, no hace falta puntero, debemos de destruir en destructor
    //List o vector por la copia
};

#endif /* TEXTOPREDICTIVO_H */


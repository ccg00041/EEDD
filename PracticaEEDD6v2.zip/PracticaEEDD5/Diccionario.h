
#ifndef DICCIONARIO_H
#define DICCIONARIO_H

#include "Palabra.h"
#include <map>
using namespace std;

class Diccionario {
public:
    Diccionario();
    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    Palabra busca(const string& termino);
    bool insertar (const string& termino);
    void cargarPalabras(string nomFich);
    unsigned int getTam(){return palabras.size();};
    void entrenaCorpus(const string& frase);
    void usaCorpus(const string& nomfich); 
    //es para dicbase distinto
    //operator=()
    void entrena(const string &termino, const string &sucesor);
    
private:
    map<string, Palabra> palabras;
    
};

#endif /* DICCIONARIO_H */



#include <stdexcept>
#include "TextoPredictivo.h"

TextoPredictivo::TextoPredictivo(Diccionario *ndiccIdioma):dicBase(ndiccIdioma){
}

TextoPredictivo::TextoPredictivo(const TextoPredictivo& orig):dicBase(orig.dicBase) {
}

list<string> TextoPredictivo::sugerencia(string termino){
//    list<string> sugerencias;
//    sugerencias=dicBase->busca(termino).sucesores();
//    return sugerencias;
}

bool TextoPredictivo::entrena(const string &termino, const string &sucesor){
    //usa try catch porque el tenia throw y al hacer catch pone return false
    //
//    dicBase->entrena(frase);
}

Usuario TextoPredictivo::getUsuario(const string& id){//cuando llamemos funcion comprobar si existe usuario
    map<string,Usuario>::iterator it=usuarios.find(id);
    if(it != usuarios.end()){
        return it->second;
    } else {
        Usuario u;
        return u;
    }
}
void TextoPredictivo::nuevoUsuario(const string &id, const string &nombre){
    try{
    map<string,Usuario>::iterator it=usuarios.at(id);
    }catch(exception& e){
        cerr << e.what() << endl;
    }
    it->first();
}
TextoPredictivo::~TextoPredictivo() {
}


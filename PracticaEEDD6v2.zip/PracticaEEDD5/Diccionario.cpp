/*
 * entrena, nuevo con dos palabras, reimplementar el antiguo y llamamos al nuevo
 * cuando hace las dos comparaiones lo podemos reusar
 * escribe frase nuevo sera nuestro antiguo entrena 
 * 
 * mapa STL, find() te da un iterador y acceder a second
 *           at te da una referencia al objeto trabajar con una excepcion. Buena opcion para buscar y acceder sucesores.
 *           [] te da una referencia al objeto te puede dar error sin saber porque. Si esta te lo devuelve, pero si no esta te mete
 *              una clave y un sucesor. Te crea el objeto si no esta.
 * 
 */
//DUDAS: busca que hace? se le llama desde alguna funcion
//

#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include "ErrorCargaFichero.h"
using namespace std;

#include "Diccionario.h"

Diccionario::Diccionario() : palabras() {
}

Diccionario::Diccionario(const Diccionario& orig) : palabras(orig.palabras) {
}

Diccionario::~Diccionario() {
}

bool Diccionario::insertar(const string& termino) {
    Palabra p(termino), pEncontrada;
    pEncontrada = busca(termino);
    if(pEncontrada.getTermino() == ""){
        palabras.insert(pair<string, Palabra>(termino, p));
        return true;
    }
    return false;
//    Palabra p(termino);
//    map<string, Palabra>::iterator it = palabras.find(termino);
//    if (it == palabras.end()) { //    if(palabras.busca(p,encontrada)){
//        palabras.insert(pair<string, Palabra>(termino, p)); //        palabras.inserta(encontrada);
//        return true;
//    } else {
//        return false;
//    }
}

Palabra Diccionario::busca(const string& termino) {
    map<string,Palabra>::iterator it = palabras.find(termino);
    Palabra p("");
    if(it == palabras.end()){
        return p;
    } else {
        return it->second;
    }
//    try {
//        Palabra p(termino);
//        Palabra pEncontrada = palabras.at(termino); //palabras.busca(p,pEncontrada);
//        return pEncontrada;
//    } catch (out_of_range &e) {
//        cout << "pensarlo"; /////////////////////ATENCION
//    }
}

void Diccionario::cargarPalabras(string nomFich) {
    //leer fichero
    ifstream fe;
    string linea;
    //    unsigned int total=0;
    fe.open(nomFich.c_str());
    if (fe.good()) {
        while (!fe.eof()) {
            fe >> linea;
            if (linea != "") {
                //crear palabra
                Palabra p(linea);
                palabras.insert(pair<string, Palabra>(linea, p));
                //                palabras.inserta(p);  
            }
        }
        fe.close();
    } else {
        throw ErrorCargaFichero();
    }

}
void Diccionario::entrenaCorpus(const string& frase){
    string termino,sucesora;
    stringstream ss;
    ss<<frase;
    ss>>termino;
    if(termino!=""){
     while(!ss.eof()){
        ss>>sucesora;
        if(sucesora!=""){
            //compruebo si la palabra existe en el diccionario
            insertar(termino); //inserta la palabra sino esta 
            //añado sucesores a la palabra
            palabras.find(termino)->second.nuevoSucesor(sucesora);
            termino=sucesora;
            sucesora="";
        } else break;
     }
    }
}

void Diccionario::entrena(const string& termino, const string& sucesor) {
    Palabra p(termino), ps(sucesor);
    insertar(termino);
    insertar(sucesor);
    palabras.at(termino).nuevoSucesor(sucesor);
    //    if(palabras.find(termino) == palabras.end()){
    //         palabras[termino]=p;                      //busca termino, si no esta lo inserta
    //    }
    //    if(palabras.find(sucesor) == palabras.end()){
    //        palabras[sucesor]=ps;//cuanto es de eficiente SIEMPRE AUMENTA EL TAMAÑO EN 1 INCLUSO CUANDO NO SE ENCUENTRA
    //    }
    //    palabras[termino].nuevoSucesor(sucesor);  //añadimos el nuevo sucesor
    //insertar el sucesor
}





void Diccionario::usaCorpus(const string& nomfich){ //usar entrenaAntiguo y el otro entrena lo usamos para usuario
    ifstream fe;
    string linea;
    stringstream ss;
    fe.open (nomfich.c_str());
    if(fe.good()){
        while (getline (fe, linea)){
            if (linea !=""){
                entrenaCorpus(linea);
            }
        }
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }

}

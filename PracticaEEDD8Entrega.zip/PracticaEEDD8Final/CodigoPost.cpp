
#include "CodigoPost.h"

CodigoPost::CodigoPost(){
}
CodigoPost::CodigoPost(string nCp, string nCiudad, string nEstado, double nLatitud, double nLongitud) 
    : codigoPostal(nCp), ciudad(nCiudad), estado(nEstado), latitud(nLatitud),
longitud(nLongitud) {
}

bool CodigoPost::operator ==(const CodigoPost& c){
    if(latitud == c.latitud && longitud == c.longitud){
        return true;
    } else {
        return false;
    }
}

CodigoPost::~CodigoPost() {
}

void CodigoPost::SetLongitud(double longitud) {
    this->longitud = longitud;
}

double CodigoPost::GetLongitud() const {
    return longitud;
}

void CodigoPost::SetLatitud(double latitud) {
    this->latitud = latitud;
}

double CodigoPost::GetLatitud() const {
    return latitud;
}

void CodigoPost::SetEstado(string estado) {
    this->estado = estado;
}

string CodigoPost::GetEstado() const {
    return estado;
}

void CodigoPost::SetCiudad(string ciudad) {
    this->ciudad = ciudad;
}

string CodigoPost::GetCiudad() const {
    return ciudad;
}

void CodigoPost::SetCodigoPostal(string codigoPostal) {
    this->codigoPostal = codigoPostal;
}

string CodigoPost::GetCodigoPostal() const {
    return codigoPostal;
}


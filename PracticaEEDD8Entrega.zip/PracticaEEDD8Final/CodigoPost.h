
#ifndef CODIGOPOST_H
#define CODIGOPOST_H
#include <string>

using namespace std;

class CodigoPost {
public:
    CodigoPost();
    CodigoPost(string nCp, string nCiudad, string nEstado, double nLatitud, double nLongitud);

    bool operator==(const CodigoPost &c);
    virtual ~CodigoPost();
    void SetLongitud(double longitud);
    double GetLongitud() const;
    void SetLatitud(double latitud);
    double GetLatitud() const;
    void SetEstado(string estado);
    string GetEstado() const;
    void SetCiudad(string ciudad);
    string GetCiudad() const;
    void SetCodigoPostal(string codigoPostal);
    string GetCodigoPostal() const;
    
private:
    string codigoPostal;//si es int se cambia de 00210 a 136
    string ciudad;
    string estado;
    double latitud; //eje x
    double longitud; //eje y
    
};

#endif /* CODIGOPOST_H */

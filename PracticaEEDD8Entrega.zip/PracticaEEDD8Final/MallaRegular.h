
#ifndef MALLAREGULAR_H
#define MALLAREGULAR_H

#include <vector>
#include <list>
#include <stdexcept>
#include <iostream>

using namespace std;

template <class T>
class MallaRegular;

template <class T>
class Casilla{
    list<T> puntos;
    public:
        friend class MallaRegular<T>;
        Casilla(): puntos(){}
        void insertar(const T &dato){puntos.push_back(dato);}
        T* buscar(const T &dato);
        bool borrar(const T &dato);
        ~Casilla(){}
};

template <class T>
T* Casilla<T>::buscar(const T& dato){
    typename list<T>::iterator it;
    for(it=puntos.begin(); it != puntos.end(); ++it){
        if(*it == dato){
            return &(*it);
        }
    }    
}

template <class T>
bool Casilla<T>::borrar(const T &dato){
    typename list<T>::iterator it;
    for(it = puntos.begin(); it != puntos.end(); ++it){
        if(*it == dato){
            puntos.erase(it);
            return true;
        }
    }
    return false;
}

template <class T>
class MallaRegular {
public:
    MallaRegular(int nXMin, int nYMin, int nXMax, int nYMax, unsigned int nNDiv); 
    vector<T> buscarRango(float rXmin, float rYmin, float rXmax,float rYmax);
    void insertar(float x, float y, const T &dato);
    T* buscar(float x, float y, const T &dato);
    bool borrar(float x, float y, const T &dato);
    ~MallaRegular(){};
    unsigned numElementos(){return elementos;};
    unsigned maxElementosEnCelda(){return maxElementos;};
    float promedioElementosPorCelda(){return(float) elementos/(nDiv*nDiv);};
private:
    float xMin, yMin, xMax, yMax;
    float tamCasillaX, tamCasillaY;
    unsigned int elementos, nDiv, maxElementos; 
    vector<vector<Casilla<T> > > mr;
    Casilla<T> *obtenerCasilla(float x, float y);
};

template <class T>
MallaRegular<T>::MallaRegular(int nXMin, int nYMin, int nXMax, int nYMax, unsigned int nNDiv)
:xMin(nXMin),yMin(nYMin),xMax(nXMax),yMax(nYMax),elementos(0),nDiv(nNDiv),maxElementos(0)
{
    tamCasillaX = (xMax -xMin)/nDiv;
    tamCasillaY = (yMax - yMin)/nDiv;
    mr.insert(mr.begin(), nDiv, vector<Casilla<T> >(nDiv));
}

template <class T>
Casilla<T> *MallaRegular<T>::obtenerCasilla(float x, float y){
    int i = (x - xMin) / tamCasillaX;
    int j = (y - yMin) / tamCasillaY;
    return &mr[j][i];
}

template <class T>
void MallaRegular<T>::insertar(float x, float y, const T &dato){
    Casilla<T> *c = obtenerCasilla(x,y);
    c->insertar(dato);
    elementos++;
    if(c->puntos.size() > maxElementos){
        maxElementos = c->puntos.size();
    }
}
template <class T> 
bool MallaRegular<T>::borrar(float x, float y, const T &dato){
    Casilla<T> *c = obtenerCasilla(x,y);
    elementos--;
    return c->borrar(dato);
}
template <class T> 
T* MallaRegular<T>::buscar(float x, float y, const T &dato){
    Casilla<T> *c = obtenerCasilla(x,y);
    return c->buscar(dato);
}
template <class T>
vector<T> MallaRegular<T>::buscarRango(float rXmin, float rYmin, float rXmax, float rYmax){
    vector<T> v;
   
    for(float i = rXmin; i <= rXmax; i += tamCasillaX ){
        for(float j = rYmin; j < rYmax; j += tamCasillaY){
            Casilla<T> *casilla= obtenerCasilla(i,j);
            for(typename list<T>::iterator it=casilla->puntos.begin();it != casilla->puntos.end(); it++){
                if(it->GetLongitud() >= rYmin && it->GetLongitud() <= rYmax && it->GetLatitud() >= rXmin && it->GetLatitud() <= rXmax){
                    v.push_back(*it);
                }
            }
        }
    }
    return v;
}
#endif /* MALLAREGULAR_H */


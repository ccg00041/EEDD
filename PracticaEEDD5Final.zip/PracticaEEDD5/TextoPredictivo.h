
#ifndef TEXTOPREDICTIVO_H
#define TEXTOPREDICTIVO_H
#include "Diccionario.h"

class TextoPredictivo {
public:
    TextoPredictivo(Diccionario *ndiccIdioma);
    TextoPredictivo(const TextoPredictivo& orig);
    list<string> sugerencia(string termino);
    void entrena(string frase);
    virtual ~TextoPredictivo();
private:
    Diccionario *dicBase;
};

#endif /* TEXTOPREDICTIVO_H */


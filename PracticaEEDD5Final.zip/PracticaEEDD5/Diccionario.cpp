#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include "ErrorCargaFichero.h"
using namespace std;

#include "Diccionario.h"

Diccionario::Diccionario():palabras(){
}

Diccionario::Diccionario(const Diccionario& orig):palabras(orig.palabras) {
}

Diccionario::~Diccionario() { 
}

bool Diccionario::insertar(const string& termino){
    Palabra p(termino), encontrada;
    if(palabras.busca(p,encontrada)){
        palabras.inserta(encontrada);
        return true;
    } else {
        return false;
    }
}




Palabra Diccionario::busca(const string& termino){
    Palabra p(termino);
    Palabra pEncontrada;
    palabras.busca(p,pEncontrada);
    return pEncontrada;
}

void Diccionario::cargarPalabras(string nomFich){
    //leer fichero
    ifstream fe;
    string linea;
    unsigned int total=0;
    fe.open (nomFich.c_str());
    if(fe.good()){
        while (!fe.eof()){
            fe >> linea;
            if (linea !=""){
                //crear palabra
                Palabra p(linea);
                palabras.inserta(p);  
            }
        }
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }
    
}
void Diccionario::entrena(const string& frase){
    string termino,sucesora;
    stringstream ss;
    ss<<frase;
    ss>>termino;
    if(termino!=""){
     while(!ss.eof()){
        ss>>sucesora;
        if(sucesora!=""){
            //compruebo si la palabra existe en el diccionario
            Palabra p(termino),pEncontrada;
            bool encontrada = palabras.busca(p,pEncontrada);
            if(!encontrada){ //sino esta, la inserto
                insertar(termino);
            }
            //añado sucesores a la palabra
            if(pEncontrada == p){
                palabras.buscaEntrena(p)->nuevoSucesor(sucesora);
            }
            termino=sucesora;
            sucesora="";
        } else break;
     }
    }
}



void Diccionario::usaCorpus(const string& nomfich){
    ifstream fe;
    string linea;
    stringstream ss;
    fe.open (nomfich.c_str());
    if(fe.good()){
        while (getline (fe, linea)){
            if (linea !=""){
                entrena(linea);
            }
        }
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }

}



#include "TextoPredictivo.h"

TextoPredictivo::TextoPredictivo(Diccionario *ndiccIdioma):dicBase(ndiccIdioma){
}

TextoPredictivo::TextoPredictivo(const TextoPredictivo& orig):dicBase(orig.dicBase) {
}

list<string> TextoPredictivo::sugerencia(string termino){
    list<string> sugerencias;
    sugerencias=dicBase->busca(termino).sucesores();
    return sugerencias;
}

void TextoPredictivo::entrena(string frase){
    dicBase->entrena(frase);
}

TextoPredictivo::~TextoPredictivo() {
}


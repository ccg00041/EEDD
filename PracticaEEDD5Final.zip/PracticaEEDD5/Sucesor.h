

#ifndef SUCESOR_H
#define SUCESOR_H
#include <iostream>
#include <string>

using namespace std;

class Sucesor {
public:
    Sucesor();
    Sucesor(string ncadena, unsigned int nnumOcurrencias);
    Sucesor(const Sucesor& orig);
    Sucesor& operator=(const Sucesor& orig);
    bool operator<(const Sucesor& s)const;
    virtual ~Sucesor();
    void SetNumOcurrencias(unsigned int numOcurrencias);
    unsigned int GetNumOcurrencias() const;
    void SetCadena(string cadena);
    string GetCadena() const;
private:
    string cadena;
    unsigned int numOcurrencias;
};

#endif /* SUCESOR_H */



#ifndef AVL_H
#define AVL_H
#include <iostream>
using namespace std;

template <class T>
class AVL {
    class Nodo;
public:
    AVL():raiz(0){};
    AVL(const AVL& orig);
    AVL& operator=(const AVL& avl);
    bool inserta(T& dato){return insertaDato(raiz,dato);}
    bool busca(T& dato, T& resultado);
    T* buscaEntrena(const T& dato);
    void recorreInorden(){inorden(raiz,0);}
    unsigned int numElementos(){return elementosAVL(raiz);};
    unsigned int altura(){calcularAltura(raiz);};
    ~AVL(){destruyeAVL(raiz);}
private:
    class Nodo {
        friend AVL;
    public:
        Nodo* izq;
        Nodo* der;
        T dato;
        char bal; //-1,0,1 balances
        
        Nodo(T& nDato) : izq(0),der(0),bal(0),dato(nDato) {}
        Nodo(const Nodo &orig):izq(orig.izq),der(orig.der),bal(orig.bal),dato(orig.dato){}
        ~Nodo() {}
    };
    
    Nodo* raiz;
    
    void rotIzqda(Nodo* &p);
    void rotDecha(Nodo* &p);
    int insertaDato(Nodo* &c,T& dato);
    AVL::Nodo *buscaElemento(Nodo* p,const T& dato);
    void inorden(Nodo* p, int nivel);
    void copiaAVL(Nodo* &p, Nodo* orig);
    void destruyeAVL(Nodo* &p);
    unsigned int elementosAVL(Nodo* p);
    unsigned int calcularAltura(Nodo* n);
    
};

template <class T>
AVL<T>::AVL(const AVL& orig){//recorrerPreorden
    copiaAVL(raiz,orig.raiz);
}

template <class T>
AVL<T>& AVL<T>::operator=(const AVL& avl){
    if(this != &avl){
        if(raiz){//si el avl tiene algun elemento libero memoria
            destruyeAVL(raiz);
        }
        copiaAVL(raiz,avl.raiz); //realizo la copia
        
    }
    return *this;
}
template <class T>
int AVL<T>::insertaDato(Nodo* &c, T& dato){
    Nodo *p = c;
    int deltaH = 0;
    if(!p){ //llega a una hoja
        p = new Nodo(dato);
        c = p;
        deltaH = 1;
    } else if(dato > p->dato){
        if(insertaDato(p->der,dato)){
            p->bal--;
            if(p->bal == -1) deltaH = 1;
            else if(p->bal == -2){
                if(p->der->bal == 1) rotDecha(p->der);//rotacion doble caso 3
                rotIzqda(c);//rotacion simple caso 4
            }
        }
    } else if(dato < p->dato){
        if(insertaDato(p->izq,dato)){
            p->bal++;
            if(p->bal == 1) deltaH = 1;
            else if(p->bal == 2){
                if (p->izq->bal == -1) rotIzqda(p->izq);//rotacion doble caso 2
                rotDecha(c);//rotacion simple caso 1
            }
        }
    }
    return deltaH;
}

template <class T>
typename AVL<T>::Nodo *AVL<T>::buscaElemento(Nodo* p, const T& dato){
    if(!p){
        return 0;
    } else if(p->dato > dato){
        return buscaElemento(p->izq, dato);
    } else if(p->dato < dato){
        return buscaElemento(p->der, dato);
    } else {
        return p;
    }
}

template <class T>
T* AVL<T>::buscaEntrena(const T& dato){
    Nodo *p=buscaElemento(raiz,dato);
    if(p!=0){
        return &(p->dato);
    } else {
        return 0;
    }
}

template <class T>
bool AVL<T>::busca(T &dato, T &resultado){
    Nodo *p = buscaElemento(raiz,dato);
    if(p){
        resultado=p->dato;
        return true;
    } else {
        return false;
    }
}

template <class T>
void AVL<T>::rotIzqda(Nodo* &p){
    Nodo *q = p,*r;
    p = r = q->der;
    q->der = r->izq;
    r->izq = q;
    q->bal++;
    if(r->bal < 0) q->bal += -r->bal;
    r->bal++;
    if(q->bal > 0) r->bal += q->bal;
}

template <class T>
void AVL<T>::rotDecha(Nodo* &p){
    Nodo *q = p,*l;
    p = l = q->izq;
    q->izq = l->der;
    l->der = q;
    q->bal--;
    if(l->bal > 0)q->bal -= l->bal;
    l->bal--;
    if(q->bal < 0)l->bal -= -q->bal;
}


template <class T>
void AVL<T>::inorden(Nodo* p, int nivel){
    if(p){
        inorden(p->izq,nivel+1);
        cout << "Procesando nodo " << p->dato << " nivel " << nivel << endl;
        inorden(p->der,nivel+1);
    }
}

template <class T>
unsigned int AVL<T>::elementosAVL(Nodo* p){
    if(p) {
        return elementosAVL(p->izq)+elementosAVL(p->der)+1;
    } else {
        return 0;
    }
    
}

template <class T>
unsigned int AVL<T>::calcularAltura(Nodo* p){
    int nivelIzq=0;
    int nivelDer=0;
    if(p){
        nivelIzq=calcularAltura(p->izq);
        nivelDer=calcularAltura(p->der);
        if(nivelIzq > nivelDer){
            return nivelIzq+1;
        } else {
            return nivelDer+1;
        }
    } else {
        return -1;
    }
}

template <class T>
void AVL<T>::copiaAVL(Nodo* &p, Nodo* orig){ //preorden
    if(orig){//si origen no es hoja, ni raiz = 0
        p = new Nodo(orig->dato); //creo nodo
        //recorro el resto del arbol y lo copio
        copiaAVL(p->izq,orig->izq);
        copiaAVL(p->der,orig->der);
    } else {
        p = 0;
    }
}

template <class T>
void AVL<T>::destruyeAVL(Nodo* &p){//postorden
    if(p){//si contiene elementos y no es hoja
        destruyeAVL(p->izq);
        destruyeAVL(p->der);
        delete p;
        p = 0;
    }
}
#endif /* AVL_H */


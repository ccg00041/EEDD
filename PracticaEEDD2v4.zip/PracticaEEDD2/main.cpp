
#include <cstdlib>
#include <iostream>
#include <string>
#include "VDinamico.h"
#include "Diccionario.h"
#include "ErrorCargaFichero.h"
using namespace std;
/*
 * 
 */
int main(int argc, char** argv) {
    try{
        unsigned int total=0;
        Diccionario d;
        d.cargarPalabras("listado-sin-acentos.txt");
        total=d.getTam();
        cout << "palabras cargadas del fichero " << total <<endl;
        string p;
        cout <<"Introducir frases y pulsar enter "<<" (Ctrl+Z para finalizar)" <<endl;
        while(!cin.eof()){
            cin >> p;
            if(p!=""){
                if(d.buscar(p)!=-1){
                    cout << "palabra ya existente en el vector" << endl;
                } else{
                    d.insertar(p);
                    cout <<"Total de palabras de diccionario "<< ++total <<endl;
                }
                p="";
            }
        }
    }catch(out_of_range &e){
        cerr <<"Fuera de rango " << e.what() <<endl;
    }catch(ErrorCargaFichero &e){
        cerr <<"Error al cargar fichero" << e.what() << endl;
    }
    
    
    return 0;
}


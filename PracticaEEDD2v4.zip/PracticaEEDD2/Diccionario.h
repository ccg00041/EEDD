

#ifndef DICCIONARIO_H
#define DICCIONARIO_H
#include "Palabra.h"
#include "VDinamico.h"

class Diccionario {
public:
    Diccionario();
    Diccionario(const Diccionario& orig);
    virtual ~Diccionario();
    
    int buscar (const string &p);
    void insertar (string &termino);
    //Palabra leer(unsigned int pos);
    void cargarPalabras(string nomFich);
    int getTam(){return palabras.tam();};
    
private:
    VDinamico<Palabra> palabras;
       
    
};

#endif /* DICCIONARIO_H */



using namespace std;

#include "Palabra.h"
#include <iostream>
#include <cstring>

Palabra::Palabra(){}
Palabra::Palabra(string termino) {
    this->termino = termino;
}

Palabra::Palabra(const Palabra& orig) {
    termino = orig.termino;
}

string Palabra::getTermino()const{
    return termino;
}

void Palabra::setTermino(string t){
    termino = t;
}

Palabra::~Palabra() {
}


/**
 * 
 */

#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>
#include "ErrorCargaFichero.h"
using namespace std;

#include "Diccionario.h"

Diccionario::Diccionario():palabras(){
    
}

Diccionario::Diccionario(const Diccionario& orig):palabras(orig.palabras) {
}

Diccionario::~Diccionario() { 
}

void Diccionario::insertar(string& termino){
    int pos;
    if(buscar(termino)==-1){
        bool encontrado=false;
        for(int i=0;i<palabras.tam()&& !encontrado;++i){
            //cout << "inserta compara " << palabras[i].getTermino() << endl;
            //cout <<palabras[i].getTermino().compare(termino) <<endl;
            if(palabras[i].getTermino().compare(termino)>0){//1º termino mayor que 2º entonces inserto
                pos=i;//empieza en 0
                encontrado=true;
            }
        }
        Palabra p(termino);
        palabras.insertar(p,pos);
        cout<<"Insertado correctamente en la posicion " << pos <<" el dato "<< termino << endl;
    }else{
        cout << "Existe esta palabra" << endl;
    }
}
int Diccionario::buscar(const string& p){
    int inf = 0;
    int sup = palabras.tam() - 1;
    int mitad;
    while( inf <= sup){
        mitad = (inf + sup)/2;
//        cout << "mitad " << mitad << endl;
//        cout << "comparando "<< v[mitad].getTermino() << endl; 
        if(palabras[mitad].getTermino() == p){                                    
//            cout << "son iguales " << mitad <<endl; 
            return mitad; 
        } 
        else if(palabras[mitad].getTermino().compare(p) < 0) inf = mitad + 1;
                 else sup = mitad - 1;
        
    }
    return -1;       
}

void Diccionario::cargarPalabras(string nomFich){
    //leer fichero
    ifstream fe;
    string linea;
    unsigned int total=0;
    //cout<<"entra en carga palabras"<< endl;
    fe.open (nomFich.c_str());
    //cout<<"abre fichero"<< endl;
    if(fe.good()){
        while (!fe.eof()){
            getline (fe, linea);
            if (linea !=""){
                //crear palabra
                Palabra p;
                p.setTermino(linea); //Introduce bien cada linea en cada palabra
                palabras.insertar(p);//añadir palabra al vector
                //cout << "palabra " << p.getTermino() << endl;
                total++;
            }
        }
        //cout<<"Total de palabras de archivo: "<<total<<endl;
        fe.close();
    }else{
        throw ErrorCargaFichero();
    }
       
    
    }

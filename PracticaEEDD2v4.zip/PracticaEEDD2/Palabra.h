
#ifndef PALABRA_H
#define PALABRA_H
#include <string>
using namespace std;


class Palabra {
public:
    Palabra();
    Palabra(string termino);
    Palabra(const Palabra& orig);
    string getTermino()const;
    void setTermino(string t);
    // &operator>(string termino);
    virtual ~Palabra();
private:
    string termino;

};

#endif /* PALABRA_H */


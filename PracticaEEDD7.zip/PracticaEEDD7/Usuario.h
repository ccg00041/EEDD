
#ifndef USUARIO_H
#define USUARIO_H

#include <string>
#include <iostream>
#include <sstream>
#include "Diccionario.h"
#include "TextoPredictivo.h"
#include <list>
using namespace std;
class TextoPredictivo;

class Usuario {
public:
    Usuario(string nid, string nnombre);
    Usuario(const Usuario& orig);
    Usuario& operator=(const Usuario &usuario); 
    list<string> sugerencia(const string &termino);
    void escribeFrase(string frase);
    virtual ~Usuario();
    void setTp(TextoPredictivo* tp);
    void setNombre(string nombre);
    string getNombre() const;
    void setId(string id);
    string getId() const;
private:
    string id;
    string nombre;
    TextoPredictivo *tp;
    Diccionario miDicc;
};

#endif /* USUARIO_H */


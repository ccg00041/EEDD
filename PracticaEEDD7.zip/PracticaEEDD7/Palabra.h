
#ifndef PALABRA_H
#define PALABRA_H
#include <string>
#include <list>
#include "Sucesor.h"
using namespace std;

class Palabra {
public:
    Palabra();
    Palabra(string ntermino);
    Palabra(const Palabra& orig);
    Palabra& operator=(const Palabra& p);
    bool operator<(const Palabra& p);
    bool operator>(const Palabra& p);
    bool operator==(const Palabra& p);
    string getTermino()const;
    void setTermino(string t);
    void nuevoSucesor(string termino);
    list<string> sucesores();
    ~Palabra();
private:
    string termino;
    list<Sucesor> siguientes;
};
 std::ostream& operator<<(ostream& out, const Palabra& p);
#endif /* PALABRA_H */


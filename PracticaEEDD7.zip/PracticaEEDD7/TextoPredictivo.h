
#ifndef TEXTOPREDICTIVO_H
#define TEXTOPREDICTIVO_H
#include "Diccionario.h"
#include "Usuario.h"

class Usuario;

class TextoPredictivo {
public:
    TextoPredictivo(Diccionario *ndicBase);
    TextoPredictivo(const TextoPredictivo& orig);
    list<string> sugerencia(string termino);
    bool entrena(const string &termino, const string &sucesor);
    void nuevoUsuario(const string &id, const string &nombre);
    Usuario* getUsuario(const string &id);
    virtual ~TextoPredictivo();
private:
    Diccionario *dicBase;
    map<string,Usuario> usuarios;
};

#endif /* TEXTOPREDICTIVO_H */


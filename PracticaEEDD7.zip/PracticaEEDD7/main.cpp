

#include <cstdlib>
#include <iostream>
#include "Diccionario.h"
#include "TextoPredictivo.h"
#include "ErrorCargaFichero.h"
#include "UsuarioNoExiste.h"
#include "THashCerrada.h"
#include <chrono>


using namespace std;

void verSucesores(list<string> sucesores,const string &palabra) {
    list<string>::iterator it = sucesores.begin();
    if (!sucesores.empty()) {
        cout << "Los sucesores de "  << palabra <<" son " << endl;
        while (it != sucesores.end()) {
            cout << *it << endl;
            it++;
        }
    } else {
        cout << palabra << " no tiene sucesores" << endl;
    }
}

/*
 * 
 */
int main(int argc, char** argv) {
    try {
//        Diccionario d;
//        d.insertar("hola");
//        d.cargarPalabras("listado-sin-acentos_v2.txt");
//        cout << d.busca("hola").getTermino() << endl;
//        
//        d.usaCorpus("corpus_spanish.txt");
        auto start = std::chrono::system_clock::now();

        Diccionario d;
        d.cargarPalabras("listado-sin-acentos_v2.txt");
        d.usaCorpus("corpus_spanish.txt");
        d.insertar("bonita");
        TextoPredictivo tp(&d);
        tp.nuevoUsuario("user1", "Maria");
        tp.nuevoUsuario("user2", "Jose");
        
        Usuario *user1 = tp.getUsuario("user1");
        user1->escribeFrase("la pelota es naranja y roja y roja y roja y amarilla y amarilla y grande y minuscula y bonita y fea");
        list<string> sugerencias = user1->sugerencia("y");
        verSucesores(sugerencias,"y");

        Usuario *user2 = tp.getUsuario("user2");
        user2->escribeFrase("me cai y tengo la pierna regulera y no puedo hacer deporte");
        list<string> sugerenciasUser2 = user2->sugerencia("pierna");
        verSucesores(sugerenciasUser2,"pierna");
        
        auto end = std::chrono::system_clock::now();
        auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
        cout << "Time spent (ms) : " << elapsed_ms << endl;
    } catch (UsuarioNoExiste &e) {
        cerr << e.what() << endl;
    } catch (ErrorCargaFichero &e) {
        cerr << "Error al cargar fichero" << e.what() << endl;
    }

    return 0;

}


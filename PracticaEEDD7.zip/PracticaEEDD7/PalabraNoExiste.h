/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#ifndef PALABRANOEXISTE_H
#define PALABRANOEXISTE_H

#include <exception>
using namespace std;

class PalabraNoExiste: public  exception{
public:
    virtual const char* what() const throw(){
        return " palabra no existe ";
    }
    virtual ~PalabraNoExiste() throw(){}
};
#endif /*PALABRANOEXISTE_H*/


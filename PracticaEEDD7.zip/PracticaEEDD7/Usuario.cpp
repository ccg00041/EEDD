#include "Usuario.h"
#include "PalabraNoExiste.h"

Usuario::Usuario(string nid, string nnombre) : id(nid), nombre(nnombre), miDicc(),tp(0) {
}

Usuario::Usuario(const Usuario& orig) : id(orig.id), nombre(orig.nombre), miDicc(orig.miDicc), tp(orig.tp) {
}

Usuario& Usuario::operator=(const Usuario& usuario) {
    if (this != &usuario) {
        id = usuario.id;
        nombre = usuario.nombre;
        miDicc = usuario.miDicc; 
        tp = usuario.tp; 
    }
    return *this;
}

list<string> Usuario::sugerencia(const string& termino) {
    list<string> listaDicBase,sucesores;
    bool existeEnDicBase=true;
    Palabra pMiDicc = miDicc.busca(termino);
    try {
        listaDicBase = tp->sugerencia(termino);
    } catch (PalabraNoExiste &e) {
        existeEnDicBase=false;
    }
    
    list<string> listaMiDicc= pMiDicc.sucesores();
    
    if(pMiDicc.getTermino() != "" && existeEnDicBase){ //Si el termino esta en los dos diccionarios
        int cont = 0;
        while(cont < 5 && !listaMiDicc.empty()){
            sucesores.push_back(listaMiDicc.front());
            listaMiDicc.pop_front();
            cont++;
        }
        cont=0;
        while(cont < 5 && !listaDicBase.empty()){
            sucesores.push_back(listaDicBase.front());
            listaDicBase.pop_front();
            cont++;
        }
        return sucesores;
    } else if(pMiDicc.getTermino() != ""){//si el termino esta en miDicc
        return listaMiDicc;
    } else if(existeEnDicBase){//Si el termino esta en dicBase
        return listaDicBase;
    }
    return sucesores;//Si no esta el termino
}

void Usuario::escribeFrase(string frase) {
    string termino, sucesor;
    stringstream ss;
    ss << frase;
    ss >> termino;
    if (termino != "") {
        while (!ss.eof()) {
            ss >> sucesor;
            if (sucesor != "") {
                //compruebo si existen en diccionario base
                bool enDiccBase = tp->entrena(termino, sucesor);
                if (!enDiccBase) { //si alguno de los dos o los dos no existen, los entrena miDicc
                    miDicc.entrena(termino, sucesor);
                }
                termino = sucesor;
                sucesor = "";
            } else break;
        }
    }
}

Usuario::~Usuario() {
}

void Usuario::setTp(TextoPredictivo* tp) {
    this->tp = tp;
}

void Usuario::setNombre(string nombre) {
    this->nombre = nombre;
}

string Usuario::getNombre() const {
    return nombre;
}

void Usuario::setId(string id) {
    this->id = id;
}

string Usuario::getId() const {
    return id;
}





#ifndef ERRORCARGAFICHERO_H
#define ERRORCARGAFICHERO_H

#include <exception>
using namespace std;

class ErrorCargaFichero: public  exception{
public:
    virtual const char* what() const throw(){
        return " No carga el fichero ";
    }
    virtual ~ErrorCargaFichero() throw(){}
};
#endif /* ERRORCARGAFICHERO_H */


#include <stdexcept>
#include "TextoPredictivo.h"
#include "PalabraNoExiste.h"
#include "UsuarioNoExiste.h"

TextoPredictivo::TextoPredictivo(Diccionario *ndicBase) : dicBase(ndicBase) {
}

TextoPredictivo::TextoPredictivo(const TextoPredictivo& orig) : dicBase(orig.dicBase) {
}

list<string> TextoPredictivo::sugerencia(string termino) {
    list<string> sugerencias;
    Palabra p; 
    try {
       p = dicBase->busca(termino);
    } catch (PalabraNoExiste &e) {
        sugerencias;
    }
    sugerencias = p.sucesores();
    return sugerencias;
}

bool TextoPredictivo::entrena(const string &termino, const string &sucesor) {
    try {
        Palabra pTermino = dicBase->busca(termino);
        Palabra pSucesor = dicBase->busca(sucesor);
    } catch (PalabraNoExiste &e) {
        return false;
    }
    //    if(pTermino.getTermino() != "" && pSucesor.getTermino() != ""){ 
    dicBase->entrena(termino, sucesor);
    return true;
    //    }
    //    return false;
}

Usuario* TextoPredictivo::getUsuario(const string& id) {
    try {
        return &usuarios.at(id);
    } catch (exception &e) {
        throw UsuarioNoExiste();
    }
}

void TextoPredictivo::nuevoUsuario(const string &id, const string &nombre) {
    map<string, Usuario>::iterator it = usuarios.find(id);
    Usuario u(id, nombre);
    u.setTp(this);
    if (it == usuarios.end()) {
        usuarios.insert(pair<string, Usuario>(id, u));
    }
}

TextoPredictivo::~TextoPredictivo() {
}


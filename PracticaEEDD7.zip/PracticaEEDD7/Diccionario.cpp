
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include "ErrorCargaFichero.h"
#include "PalabraNoExiste.h"
using namespace std;

#include "Diccionario.h"

Diccionario::Diccionario() : palabras(132283) {
}/* EXPLORACIONCUADRATICA:130500,131697,135017,134753,133033,132893 EL MEJOR:132283*/
/*DISPERSION DOBLE:130500,131697*/

Diccionario::Diccionario(const Diccionario& orig) : palabras(orig.palabras) {
}

Diccionario& Diccionario::operator=(const Diccionario& d) {
    if (this != &d) {
        //        palabras.clear();
        palabras = d.palabras;
    }
    return *this;
}

Diccionario::~Diccionario() {
}

void Diccionario::insertar(const string& termino) {
    Palabra p(termino);
    unsigned long clave = djb2((unsigned char*) termino.c_str());
    palabras.insertar(clave, p);
}



Palabra& Diccionario::busca(const string& termino) {
    unsigned long clave = djb2((unsigned char*) termino.c_str());
    Palabra p(termino);
    Palabra *pa = palabras.buscar(clave, p);
    if (pa == 0) {
//        cout << "excepcion palabra no encontrada " << termino << endl;
        throw PalabraNoExiste();
    }
    return *pa;
}



void Diccionario::cargarPalabras(string nomFich) {
    //leer fichero
    ifstream fe;
    string linea;
    fe.open(nomFich.c_str());
    if (fe.good()) {
        while (!fe.eof()) {
            fe >> linea;
            if (linea != "") {
                //crear palabra
                //                Palabra p(linea);
                //llamar jb2 (unsigned long posicion = THashCerrado<Palabra>::djb2((unsigned char*)linea.c_str())
                //palabras.insertar();
                insertar(linea);
            }
        }
        fe.close();
    } else {
        throw ErrorCargaFichero();
    }
    cout << "max colisiones " << palabras.maxColisiones() << endl;
    cout << "factor de carga " << palabras.factorCarga() << endl;
    cout << "elementos insertados  " << palabras.numElementos() << endl;
    cout << "promedio colisiones  " << palabras.promedioColisiones() << endl;
}


void Diccionario::entrenaCorpus(const string& frase) {
    string termino, sucesora;
    stringstream ss;
    ss << frase;
    ss>>termino;
    if (termino != "") {
        while (!ss.eof()) {
            ss>>sucesora;
            if (sucesora != "") {
                Palabra p(termino);
                insertar(termino); //inserto la palabra sino existe
                //                palabras.buscar(djb2((unsigned char*) termino.c_str()),p)->nuevoSucesor(sucesora); //aÃ±ado sucesores
                //esto esta bien?¿?
                busca(termino).nuevoSucesor(sucesora);

                //                cout << "entrenado termino " << termino << endl;
                termino = sucesora;
                sucesora = "";
            } else break;
        }
    }
}

void Diccionario::entrena(const string& termino, const string& sucesor) {
    Palabra p(termino), ps(sucesor);
    insertar(termino);
    insertar(sucesor);
//    cout << "da fallo" << endl;
   busca(termino).nuevoSucesor(sucesor);
    
}


void Diccionario::usaCorpus(const string& nomfich) {
    ifstream fe;
    string linea;
    stringstream ss;
    fe.open(nomfich.c_str());
    if (fe.good()) {
        while (getline(fe, linea)) {
            if (linea != "") {
//                cout << "usacorpus1 " << linea << endl;
                entrenaCorpus(linea);
                //                cout << "usacorpusn " << linea << endl;
            }
        }
        fe.close();
    } else {
        throw ErrorCargaFichero();
    }
    cout << "max colisiones " << palabras.maxColisiones() << endl;
    cout << "factor de carga " << palabras.factorCarga() << endl;
    cout << "elementos insertados  " << palabras.numElementos() << endl;
}



unsigned long Diccionario::djb2(const unsigned char *str) {
    unsigned long hash = 5381;
    int c;
    while (c = *str++) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

#ifndef USUARIONOEXISTE_H
#define USUARIONOEXISTE_H

#include <exception>
using namespace std;

class UsuarioNoExiste: public  exception{
public:
    virtual const char* what() const throw(){
        return " usuario no existe ";
    }
    virtual ~UsuarioNoExiste() throw(){}
};
#endif /* USUARIONOEXISTE_H */

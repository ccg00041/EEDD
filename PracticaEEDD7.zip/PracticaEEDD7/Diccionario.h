
#ifndef DICCIONARIO_H
#define DICCIONARIO_H

#include "Palabra.h"
#include "THashCerrada.h"
#include <map>
using namespace std;

class Diccionario {
public:
    Diccionario();
    Diccionario(const Diccionario& orig);
    Diccionario& operator=(const Diccionario& d);
    virtual ~Diccionario();
    Palabra& busca(const string& termino);
    void insertar (const string& termino);
    void cargarPalabras(string nomFich);
    unsigned int getTam(){return palabras.numElementos();};
    void entrenaCorpus(const string& frase);
    void usaCorpus(const string& nomfich); 
    void entrena(const string &termino, const string &sucesor);
    
private:
//    map<string, Palabra> palabras;
    THashCerrada<Palabra> palabras;
    unsigned long djb2(const unsigned char *str);
};

#endif /* DICCIONARIO_H */


#ifndef THASHCERRADA_H
#define THASHCERRADA_H
#include <vector>
#include <iostream>
using namespace std;
//Se va a usar usa corpus
//que funciones son inline
//constructores necesarios
/*
//CLASE Dudas de dispersion: vector de stl, tamaño de la tabla tiene tamaño fijo, no vamos a hacer redispersion, en stl 
//constructor (size,entrada) en diccionario
//Insercion: obtengo posicion de dispersion djb2-> si el elemento ocupada busco otro valor valido, hasta encontrar una posicion
//vacia, otra situacion, si doy más de los saltos recomendados(num intentos) y no encuentro -> excepcion no hay espacio
//si quiero insertar algo que ya existe-> no hacer nada o sustituir
//BUSQUEDA:
//si he insertado hasta n datos, devolvemos referencia o puntero al campo de entrada para poder añadirle sucesores
 * termino la busqueda cuando lo encuentra o cuando llega a una posición vacia -> no esta, o cuando se llega hacen n intentos
 * si es puntero devuelvo 0, sino lanzo excepcion
 * BORRADO:
 * borrado perezoso, marco su estado a disponible/borrado, se puede usar para inserar elementos pero en la busqueda se salta
 * borrado para cuando lo encuentras, n intentos, no existe (que devuelva falso o no haga nada)
 * al borrar solo comparo los ocupados, por tanto en cuanto llego a una posicion vacia ya salgo de borrar
 * ULTIMA SITUACION ACABAR EN INSERTA: si la posicion esta ocupada paso a siguiente y en una casilla borrada puedo insertar
//comparamos por el operator == palabra
**/
template <class T>
class Entrada {
public:
//    unsigned long clave;NO HACE FALTA
    T dato;
    unsigned int estadoCasilla; //vacia=0,disponible=1,ocupada=2
    Entrada() : estadoCasilla(0) {}
    Entrada(T nDato) : dato(nDato), estadoCasilla(0) {}
    ~Entrada() {}
//
//    unsigned int getEstadoCasilla() const {
//        return estadoCasilla;
//    }
//    void setEstadoCasilla(unsigned int nEstadoCasilla) {
//        this->estadoCasilla = nEstadoCasilla;
//    }
//
//    void setDato(T dato) {
//        this->dato = dato;
//    }
//
//    T getDato() const {
//        return dato;
//    }
};

template <class T>
class THashCerrada {
public:

    THashCerrada(unsigned int ntamf):maxColision(0),promeColisiones(0),taml(0),tamf(ntamf),tHash(ntamf,Entrada<T>()) { }
//    THashCerrada(const THashCerrada& orig);

    virtual ~THashCerrada() {};
    bool insertar(unsigned long clave, const T &dato);
    bool borrar(unsigned long clave, const T &dato);
    T* buscar(unsigned long clave, const T &dato);

    unsigned int tamaTabla() {return tamf;}
    unsigned int numElementos(){return taml;}
    unsigned int maxColisiones(){return maxColision;}
    float promedioColisiones(){return  (float)promeColisiones/taml;}

    float factorCarga() {return (float)taml / tamf;}

private:
    
    unsigned int taml;
    unsigned int tamf;//130500 130513
    unsigned int maxColision;
    unsigned int promeColisiones; //FALTA PONER
    vector<Entrada<T> > tHash; 
    unsigned long fExploracionCuadratica(unsigned long clave, int intento);
    unsigned long fExploracionCuadraticav2(unsigned long clave, int intento);//PRUEBA
    unsigned long fdispersionDoble(unsigned long clave, int intento);
    bool primo(unsigned int n);


};


template <class T>
unsigned long THashCerrada<T>::fExploracionCuadratica(unsigned long clave, int intento) {
//    cout << clave << " tam " << TAMF << endl;
    return (clave + intento*intento) % tamf;
}



template <class T> 
unsigned long THashCerrada<T>::fdispersionDoble(unsigned long clave, int intento){
    unsigned long h1 = (clave % tamf);
    unsigned long h2 = 2731 - (clave % 2731);//h2 = 1 + (clave % 2731)
    return (h1 + intento*h2) % tamf;
}

template <class T>
bool THashCerrada<T>::insertar(unsigned long clave, const T& dato) {
    unsigned int colisiones = 0;
//    unsigned long posicion = fExploracionCuadratica(clave,colisiones);
    unsigned long posicion = fdispersionDoble(clave,colisiones);
    while(tHash.at(posicion).estadoCasilla == 2){//si la posicion esta ocupada
        if(tHash.at(posicion).dato == dato){ //si el dato esta ya insertado no lo inserto 
//            cout << "hay elemento repetido " << dato << endl;
            return true;
        }
//        posicion = fExploracionCuadratica(clave,++colisiones);
        posicion = fdispersionDoble(clave,++colisiones);
    }
    if(colisiones > maxColision){
        maxColision = colisiones;
    }
    if(colisiones > 50){
        cout << "Palabra no insertada " << dato << endl;
        return false;
    }
    
    Entrada<T> e(dato);
    tHash[posicion].estadoCasilla=2;
    tHash[posicion].dato = dato;
    cout << "insertada dato: " << dato << endl;
    promeColisiones += colisiones;
    taml++;
    //    cout << "elemento insertado " << tHash[posicion].dato << endl;
//    cout << "tamal thash " << tHash.size() << " tamal " << taml << endl;
//    cout << "termino insertado " << endl;
    return true;
}



template <class T>
T* THashCerrada<T>::buscar(unsigned long clave, const T& dato){
    
    int colision = 0;
    unsigned long posicion = fdispersionDoble(clave,colision);
    while((tHash.at(posicion).estadoCasilla == 2 ) && colision < 50){//y que pasa si en la secuencia una ha sido marcada como borrada?¿ creo que me falta
        if(tHash.at(posicion).dato == dato){
            return &(tHash.at(posicion).dato);
        }
        posicion = fdispersionDoble(clave,++colision);
    }
    return 0;
}

template <class T>
bool THashCerrada<T>::borrar(unsigned long clave, const T& dato){
    int colision = 0;
    unsigned long posicion = fdispersionDoble(clave,colision);
    while(tHash.at(posicion).estadoCasilla == 2 && colision < 50){
        if(tHash.at(posicion).dato == dato){
            tHash[posicion].estadoCasilla = 1;//marco casilla a borrada/disponible
            taml--;
            return true;
        }
        posicion = fdispersionDoble(clave,++colision);
    }
    return false;
}

#endif /* THASHCERRADA_H */

